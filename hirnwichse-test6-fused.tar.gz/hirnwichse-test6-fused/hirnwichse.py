#!/usr/bin/env python3.6

from pyximport import install
install()

from hirnwichse_main import Hirnwichse

if (__name__ == '__main__'):
    Hirnwichse()

